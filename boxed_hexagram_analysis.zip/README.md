# Boxed Hexagram (BH24): board specification and simulation

This is a proposed **second board** using the existing four-stone game mechanics. Its graph is an explicit interpretation of the hand drawing, not a claim that every crossing on an irregular sketch has been unambiguously specified.

## Layout

- 24 playable vertices, 13 straight movement tracks.
- Coordinates are from White's perspective: A..I left-to-right, ranks 1..7 bottom-to-top; unused grid cells are not vertices.
- All line crossings are playable and stop-capable; *crossing tracks* permit direction changes **between** moves, but a stone must follow one straight track in a single move.
- The original box, two overlapping triangles and left/right external T-posts are included.
- External terminals A3/I3 are exclusive to White; A5/I5 are exclusive to Black. Every vertex inside or on the enclosing square may be occupied by either colour.

| Rank | Playable coordinates |
|---|---|
| 7 | B7 E7 H7 |
| 5 | A5 B5 D5 F5 H5 I5 |
| 4 | A4 B4 C4 G4 H4 I4 |
| 3 | A3 B3 D3 F3 H3 I3 |
| 1 | B1 E1 H1 |

Starting stones: White at `B1 H1 A3 I3`, Black at `B7 H7 A5 I5`. White goes first.

Winning: White must hold `D5 E7 F5` simultaneously; Black must hold `D3 E1 F3` simultaneously. The central intersections C4/G4 are **not** victory targets.

### Exact straight tracks

```
B7 E7 H7
B1 E1 H1
B7 B5 B4 B3 B1
H7 H5 H4 H3 H1
A5 A4 A3
I5 I4 I3
A4 B4 C4 G4 H4 I4
B5 D5 F5 H5
B3 D3 F3 H3
E7 D5 C4 B3
E7 F5 G4 H3
B5 C4 D3 E1
H5 G4 F3 E1
```

All consecutive nodes on a listed track share an edge. A stone may pass multiple empty intermediate nodes but must stop at an empty vertex and may not bend during the move.

## Rules in simulator

- Four stones per colour; internal tracking IDs are used solely to enforce the last-moved restriction, not for displayed identities.
- The same stone cannot make a voluntary move on two consecutive turns by its owner; each colour has an independent restriction.
- Long-range custodial capture: **the stone just moved** is one endpoint of a bracket, a friendly stone is at the opposite endpoint, and **exactly one enemy stone** with no other occupied points lies between on a *single straight track*. Captured stones are displaced, not eliminated.
- Captured player chooses any unoccupied home for the return; returning costs no normal turn. If all four are occupied, a captured stone stays in reserve until a legal redeployment (which costs a normal turn).
- Two or more captures on a move are returned in succession by the defender.
- Player without legal voluntary movement must pass. Passing does not clear their previous-stone restriction. Both unable to move: draw.
- No repetition restriction or real-game move cap. A computational cut-off is reported **unresolved**, never a draw.

## Run

```sh
python3 -m unittest test_board.py -v
python3 boxed_hexagram_solver.py --games 600 --depth 2 --limit 180 --output boxed_hexagram_results.json
```

Only Python standard library is required. `make_board.py` generates the SVG and JSON graph definition. SVG rendering is optional for game simulation.

## Findings and limitations

See `boxed_hexagram_results.json` for the 600-game sample. It combines four equal-sized match-ups: greedy/greedy, random/random, search/greedy and greedy/search. Search uses a two-ply depth with a beam cap; it is not a full-state solver. Its outcomes are **not proof** of first-player balance, forced wins or a solved game.

The exact victory targets and the ability to treat crossings as nodes reflect the photographed sketch. Before using this board in a production game, confirm the proposed SVG and its labels match the intended physical design.

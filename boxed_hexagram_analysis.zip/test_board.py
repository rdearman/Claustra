import unittest
from dataclasses import replace
import boxed_hexagram_solver as g

class BoardTests(unittest.TestCase):
 def test_graph(self):
  self.assertEqual(len(g.NAMES),24)
  self.assertEqual(len(g.TRACKS),13)
  self.assertEqual(len(g.occupied(g.START)),8)
  self.assertEqual(g.audit(),2500)
 def test_long_range_capture(self):
  # White moves from B5 to D5 to bracket Black on F5 against White on H5.
  s=g.State(((g.ID['H5'],g.ID['B5'],g.ID['B1'],g.ID['A3']),
    (g.ID['F5'],g.ID['B7'],g.ID['H7'],g.ID['A5'])),turn=g.WHITE)
  a=g.Action('move',1,g.ID['B5'],g.ID['D5'])
  n=g.resolve(s,a)
  self.assertEqual(n.pending,(0,))
  self.assertEqual(n.pieces[g.BLACK][0],g.OFF)
  self.assertTrue(any(q.dst==g.ID['H5'] for q in g.legal_actions(n)) is False)  # occupied by White
 def test_blocked_bracket(self):
  # Another Black stone between captured and anchor prevents capture.
  s=g.State(((g.ID['H5'],g.ID['B5'],g.ID['B1'],g.ID['A3']),
    (g.ID['F5'],g.ID['B7'],g.ID['H7'],g.ID['D5'])),turn=g.WHITE)
  # D5 is occupied: a legal move must not pass or land there.
  self.assertNotIn(g.Action('move',1,g.ID['B5'],g.ID['D5']),g.moves(s))
 def test_no_capture_across_bend(self):
  # Mover B4 and anchor E7 cannot capture C4: they are not on one track.
  s=g.State(((g.ID['E7'],g.ID['B5'],g.ID['B1'],g.ID['A3']),
    (g.ID['C4'],g.ID['B7'],g.ID['H7'],g.ID['I5'])),turn=g.WHITE)
  a=g.Action('move',1,g.ID['B5'],g.ID['B4'])
  self.assertIn(a,g.moves(s))
  n=g.resolve(s,a)
  self.assertFalse(n.pending)
 def test_own_exterior_only(self):
  s=g.START
  for a in g.moves(s):self.assertNotIn(a.dst,g.PROTECTED[g.BLACK])
 def test_consecutive_move_and_return(self):
  s=g.START
  a=next(a for a in g.moves(s) if a.kind=='move')
  n=g.resolve(s,a)
  # Look at White's next turn without changing stone's state.
  white_next=replace(n,turn=g.WHITE)
  self.assertFalse(any(x.stone==a.stone for x in g.moves(white_next)))
 def test_pass_without_reset(self):
  s=replace(g.START,last=(2,-1),turn=g.WHITE)
  # Pass permitted only if all other stones are blocked; test pass transition
  # using deliberately immobile constructed positions, not fake voluntary pass.
  self.assertNotIn(g.Action('pass'),g.legal_actions(s))
 def test_win_rule(self):
  white=(g.ID['D5'],g.ID['E7'],g.ID['F5'],g.ID['A3'])
  black=(g.ID['B7'],g.ID['H7'],g.ID['A5'],g.ID['I5'])
  self.assertEqual(g.winner(g.State((white,black))),g.WHITE)
  white=(g.ID['D5'],g.ID['E7'],g.ID['B1'],g.ID['A3'])
  self.assertIsNone(g.winner(g.State((white,black))))

if __name__=='__main__':unittest.main()

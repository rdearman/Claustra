#!/usr/bin/env python3
"""Boxed Hexagram: exact 24-vertex graph and interchangeable 4-stone rules.

Coordinates from White's perspective. The track graph (not geometric proximity)
is authoritative. This is a finite-horizon adversarial simulator, NOT an
exhaustive game-theoretic solution.
"""
from __future__ import annotations
from collections import Counter, deque
from dataclasses import dataclass, replace
from functools import lru_cache
from random import Random
import argparse, json, statistics

# Graph coordinates use A..I (left-to-right) and ranks 1..7 (bottom-to-top).
# Every crossing in the drawing, including diagonal crossings, is an intersection.
XY = {
 'B7':(0,6),'E7':(3,6),'H7':(6,6),
 'A5':(-1,4),'B5':(0,4),'D5':(1.5,4),'F5':(4.5,4),'H5':(6,4),'I5':(7,4),
 'A4':(-1,3),'B4':(0,3),'C4':(.75,3),'G4':(5.25,3),'H4':(6,3),'I4':(7,3),
 'A3':(-1,2),'B3':(0,2),'D3':(1.5,2),'F3':(4.5,2),'H3':(6,2),'I3':(7,2),
 'B1':(0,0),'E1':(3,0),'H1':(6,0),
}
TRACKS = (
 ('B7','E7','H7'), ('B1','E1','H1'),
 ('B7','B5','B4','B3','B1'), ('H7','H5','H4','H3','H1'),
 ('A5','A4','A3'), ('I5','I4','I3'),
 ('A4','B4','C4','G4','H4','I4'),
 ('B5','D5','F5','H5'), ('B3','D3','F3','H3'),
 ('E7','D5','C4','B3'), ('E7','F5','G4','H3'),
 ('B5','C4','D3','E1'), ('H5','G4','F3','E1'),
)
NAMES=tuple(XY)
ID={s:i for i,s in enumerate(NAMES)}
N=len(NAMES)
assert N==24
WHITE, BLACK = 0, 1
HOME=(('B1','H1','A3','I3'),('B7','H7','A5','I5'))
SAFE=(frozenset(('A3','I3')),frozenset(('A5','I5')))
# The opposing triangle's apex and its two intersections on the horizontal base.
GOAL=(frozenset(('D5','E7','F5')),frozenset(('D3','E1','F3')))
OFF=-1
HOMES=tuple(tuple(ID[x] for x in h) for h in HOME)
PROTECTED=tuple(frozenset(ID[x] for x in h) for h in SAFE)
GOALS=tuple(frozenset(ID[x] for x in h) for h in GOAL)
RAYS=[[] for _ in range(N)]
CAPTURES=[[] for _ in range(N)]
ADJ=[set() for _ in range(N)]
for track in TRACKS:
    v=[ID[x] for x in track]
    for a,b in zip(v,v[1:]):ADJ[a].add(b);ADJ[b].add(a)
    for k,x in enumerate(v):
        for seq in (v[k+1:],list(reversed(v[:k]))):
            if seq:RAYS[x].append(tuple(seq))
        for j,endpoint in enumerate(v):
            if endpoint==x or abs(j-k)<2:continue
            mid=tuple(v[min(j,k)+1:max(j,k)])
            CAPTURES[x].append((endpoint,mid))

@lru_cache(None)
def distance(a:int,b:int):
    if a==b:return 0
    q=deque([(a,0)]);seen={a}
    while q:
        x,d=q.popleft()
        for y in ADJ[x]:
            if y==b:return d+1
            if y not in seen:q.append((y,d+1));seen.add(y)
    return 99

@dataclass(frozen=True,slots=True)
class State:
    # Four distinct internal slots allow tracking *only* the last moved stone.
    # The slots are never exposed as numbered physical pieces.
    pieces: tuple[tuple[int,...],tuple[int,...]]
    last: tuple[int,int]=(-1,-1)
    turn:int=WHITE
    # Captured owner chooses where to put these stones before normal play resumes.
    pending:tuple[int,...]=()
    # Who plays normally after the pending return choice.
    after_return:int=-1
    passes:int=0

START=State(tuple(tuple(ID[x] for x in homes) for homes in HOME))

@dataclass(frozen=True,slots=True)
class Action:
    kind:str
    stone:int=-1
    src:int=OFF
    dst:int=OFF
    captures:tuple[int,...]=()

def occupied(s:State):
    return {p for side in s.pieces for p in side if p>=0}

def winner(s:State):
    for side in (WHITE,BLACK):
        if GOALS[side].issubset(set(s.pieces[side])):return side
    return None

def moves(s:State,ignore_pending=False):
    if winner(s) is not None:return ()
    occ=occupied(s);p=s.turn
    if s.pending and not ignore_pending:
        # Always offer every available home, not only the best one.
        homes=[h for h in HOMES[p] if h not in occ]
        if homes:return tuple(Action('return',s.pending[0],OFF,h) for h in homes)
        return (Action('defer'),)
    ans=[]
    for stone,src in enumerate(s.pieces[p]):
        if stone==s.last[p]:continue
        if src==OFF:
            for h in HOMES[p]:
                if h not in occ:ans.append(Action('deploy',stone,OFF,h))
            continue
        for ray in RAYS[src]:
            for dst in ray:
                if dst in occ:break
                if dst in PROTECTED[1-p]:continue
                ans.append(Action('move',stone,src,dst))
    return tuple(ans)

def resolve(s:State,a:Action):
    """Apply one normal move, forced pass, captured-stone return or deferral."""
    if a not in legal_actions(s):raise ValueError(f'illegal {a}')
    p=s.turn
    if a.kind=='return':
        pp=[list(x) for x in s.pieces]
        pp[p][a.stone]=a.dst
        next_pending=s.pending[1:]
        return State(tuple(map(tuple,pp)),s.last,
                     p if next_pending else s.after_return,
                     next_pending, s.after_return if next_pending else -1,s.passes)
    if a.kind=='defer':
        return replace(s,pending=(),turn=s.after_return,after_return=-1)
    if a.kind=='pass':
        return replace(s,turn=1-p,passes=s.passes+1)
    pp=[list(x) for x in s.pieces]
    pp[p][a.stone]=a.dst
    ls=list(s.last);ls[p]=a.stone
    victims=[]
    if a.kind=='move':
        # A moved stone is one *endpoint* of the bracket. Capture only if
        # exactly one enemy and no other stone lies between the endpoints.
        me=set(pp[p]);other=set(pp[1-p]);occ=me|other
        for far,interior in CAPTURES[a.dst]:
            if far not in me:continue
            contents=[v for v in interior if v in occ]
            if len(contents)==1 and contents[0] in other:
                victim=pp[1-p].index(contents[0]);victims.append(victim)
    victims=tuple(sorted(set(victims)))
    for victim in victims:pp[1-p][victim]=OFF
    ps=tuple(map(tuple,pp))
    # Placing the mover on an immediate victory formation ends play.
    if victims:
        return State(ps,tuple(ls),1-p,victims,p,0)
    return State(ps,tuple(ls),1-p,(),-1,0)

def legal_actions(s:State):
    opts=moves(s)
    if opts:return opts
    if not s.pending:return (Action('pass'),)
    raise AssertionError('pending must always resolve')

def ended(s:State):
    if winner(s) is not None:return True
    if s.pending:return False
    # Genuine stalemate iff neither player has any permissible voluntary move.
    if moves(s):return False
    opposite=replace(s,turn=1-s.turn)
    return not bool(moves(opposite))

def evaluate(s:State,side:int):
    win=winner(s)
    if win is not None:return (100000 if win==side else -100000)
    mine=s.pieces[side];theirs=s.pieces[1-side]
    # Occupancy, coverage and distance to all three target nodes.
    def pos_score(p,colour):
        occupied_p=set(p)
        goals=GOALS[colour]
        val=0.0
        held=len(goals&occupied_p)
        val+=30*held + 12*held*held
        for g in goals:
            if g not in occupied_p:
                ds=[distance(x,g) for x in p if x>=0]
                val+=max(0,13-3*(min(ds) if ds else 8))
        val-=10*p.count(OFF)
        return val
    return pos_score(mine,side)-pos_score(theirs,1-side)

def find_best(s:State,rng:Random,depth=2,noise=2.,beam=10):
    """Deterministic alpha-beta in positions except seeded tie noise at root.

    A return choice belongs to the *defender* and is minimised/maximised
    according to whose decision it is, not whichever side just made a capture.
    """
    options=legal_actions(s)
    root=s.turn
    @lru_cache(maxsize=12000)
    def recur(st:State,rem:int,alpha:float,beta:float):
        if winner(st) is not None:return evaluate(st,root)
        if ended(st):return 0
        if rem<=0 and not st.pending:return evaluate(st,root)
        opts=legal_actions(st)
        maximize=st.turn==root
        # Capture-return decisions are mandatory and must be explored without
        # consuming normal-move depth.
        ordered=sorted(opts,key=lambda a:evaluate(resolve(st,a),root),reverse=maximize)
        if not st.pending:ordered=ordered[:beam]
        value=-1e9 if maximize else 1e9
        for a in ordered:
            nxt=resolve(st,a)
            nrem=rem if st.pending else rem-1
            v=recur(nxt,nrem,alpha,beta)
            if maximize:
                value=max(value,v);alpha=max(alpha,value)
            else:
                value=min(value,v);beta=min(beta,value)
            if beta<=alpha:break
        return value
    scored=[]
    for a in options:
        ns=resolve(s,a)
        value=recur(ns,depth-1,-1e9,1e9)
        scored.append((value+rng.uniform(-noise,noise),a))
    return max(scored,key=lambda z:z[0])[1]

def play(seed:int,white_policy='greedy',black_policy='greedy',depth=2,limit=160,noise=4,record=False):
    rng=Random(seed);s=START;history=[];ply=0;captures=0;passes=0
    seen=Counter()
    while ply<limit:
        w=winner(s)
        if w is not None:return dict(outcome='white' if w==WHITE else 'black',plies=ply,captures=captures,passes=passes,history=history)
        if ended(s):return dict(outcome='draw',plies=ply,captures=captures,passes=passes,history=history)
        # Track cycles as a diagnostic only; do NOT turn them into game-rule draws.
        if not s.pending:seen[s]+=1
        act=legal_actions(s)
        if s.pending:
            # The defending player's return choice is consequential; select by
            # that player's own strategy, even when they are the computer.
            policy=white_policy if s.turn==WHITE else black_policy
        else:policy=white_policy if s.turn==WHITE else black_policy
        if policy=='random':a=rng.choice(act)
        elif policy=='greedy':
            opts=[(evaluate(resolve(s,a),s.turn)+rng.uniform(-noise,noise),a) for a in act]
            a=max(opts,key=lambda t:t[0])[1]
        elif policy=='search':a=find_best(s,rng,depth,noise)
        else:raise ValueError(policy)
        nxt=resolve(s,a)
        if record:history.append((('W' if s.turn==0 else 'B'),a.kind, NAMES[a.src] if a.src>=0 else '',NAMES[a.dst] if a.dst>=0 else '',tuple(NAMES[s.pieces[1-s.turn][v]] for v in a.captures if s.pieces[1-s.turn][v]>=0)))
        captures+=len(nxt.pending) if a.kind=='move' else 0
        passes+=a.kind=='pass'
        if a.kind in ('move','deploy','pass'):ply+=1
        s=nxt
    return dict(outcome='unresolved',plies=ply,captures=captures,passes=passes,history=history,repeat_states=sum(v>=3 for v in seen.values()))

def audit():
    # Geometry and symmetry: swap colour and flip vertically in actual coordinates.
    assert len(XY)==24
    assert all(len(set(t))==len(t) for t in TRACKS)
    assert {x for t in TRACKS for x in t}==set(XY)
    assert all(len(h)==4 for h in HOME)
    assert not (SAFE[0]&SAFE[1])
    assert GOAL[0]==frozenset(('D5','E7','F5'))
    assert GOAL[1]==frozenset(('D3','E1','F3'))
    assert NAMES[ID['C4']]=='C4'
    assert all(g not in SAFE[0]|SAFE[1] for gs in GOAL for g in gs)
    mirror={ID[n]:ID[next(k for k,(x2,y2) in XY.items() if abs(x2-XY[n][0])<1e-9 and abs(y2-(6-XY[n][1]))<1e-9)] for n in NAMES}
    lines={tuple(t) for t in TRACKS}
    assert all(tuple(NAMES[mirror[ID[x]]] for x in reversed(t)) in lines or tuple(NAMES[mirror[ID[x]]] for x in t) in lines for t in TRACKS)
    assert [set(NAMES[mirror[x]] for x in HOMES[0])]==[set(HOME[1])]
    assert set(NAMES[mirror[x]] for x in GOALS[WHITE])==set(GOAL[BLACK])
    assert set(NAMES[mirror[x]] for x in PROTECTED[WHITE])==set(SAFE[BLACK])
    # All starting positions distinct, no immediate win and every side has mobility.
    assert len(occupied(START))==8 and winner(START) is None
    assert len(moves(START))>0
    # Direct initial centre access should not be assumed: test is whether legal.
    # Unavailable enemy exterior posts must not be valid move destinations.
    assert all(a.dst not in PROTECTED[BLACK] for a in moves(START) if a.kind=='move')
    # Inspect a reachable state by generating random actions.
    rng=Random(1234);s=START;n=0
    for _ in range(2500):
        if winner(s) is not None or ended(s):s=START
        acts=legal_actions(s)
        a=rng.choice(acts)
        ns=resolve(s,a)
        assert len(ns.pieces[0])==4 and len(ns.pieces[1])==4
        assert len(occupied(ns))==sum(v>=0 for z in ns.pieces for v in z)
        assert all(v not in PROTECTED[1-p] for p,pieces in enumerate(ns.pieces) for v in pieces if v>=0)
        if a.kind=='move':assert ns.last[s.turn]==a.stone
        if a.kind in ('return','defer','pass'):assert ns.last==s.last
        if ns.pending and a.kind=='move':assert ns.turn==1-s.turn
        s=ns;n+=1
    # Construct a long-range bracket on upper horizontal B5-D5-F5-H5.
    # Mover D5, enemy F5, anchor H5; capture succeeds despite empty gaps
    # if the enemy is the only occupied middle point.
    p0=(ID['H5'],ID['D3'],ID['B1'],ID['A3'])
    p1=(ID['F5'],ID['B7'],ID['H7'],ID['A5'])
    s=State((p0,p1),turn=WHITE)
    # Place a White stone on B5 and move it to D5 (D5 lies to left of enemy F5).
    s=State(((ID['H5'],ID['B5'],ID['B1'],ID['A3']),p1),turn=WHITE)
    a=Action('move',1,ID['B5'],ID['D5'])
    assert a in moves(s)
    ns=resolve(s,a)
    assert ns.pending==(0,) and ns.pieces[BLACK][0]==OFF
    # Tracking lasts separately for each side; pass never clears it.
    after=replace(ns,pending=(),turn=WHITE,after_return=-1)
    assert after.last[WHITE]==1
    assert all(a.stone!=1 for a in moves(after) if a.kind=='move')
    return n

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--games',type=int,default=250)
    ap.add_argument('--depth',type=int,default=2)
    ap.add_argument('--limit',type=int,default=160)
    ap.add_argument('--seed',type=int,default=20261107)
    ap.add_argument('--output',default='')
    args=ap.parse_args()
    checked=audit();print(f'Audit PASS: {len(NAMES)} vertices, {len(TRACKS)} tracks, {checked} reachable transitions')
    print(f'Initial legal White moves: {len(moves(START))}')
    print('Starting positions:', HOME, 'Goals:', GOAL, 'Protected:',SAFE)
    # Balanced fixtures: same number of games with both sides using each policy.
    matchups=[('greedy','greedy'),('random','random'),('search','greedy'),('greedy','search')]
    counts=[args.games//len(matchups)+(i<args.games%len(matchups)) for i in range(len(matchups))]
    report={'board':'Boxed Hexagram','vertices':len(NAMES),'rules':'long-range capture; defender return choice; previous-stone restriction; forced passes; mutual immobility draws; 3 nonshared goal vertices','games_requested':args.games,'search_depth':args.depth,'cutoff_plies':args.limit,'matchups':{}}
    overall=Counter();lengths=[]
    for i,((w,b),count) in enumerate(zip(matchups,counts)):
        co=Counter();ls=[];cap=0;passes=0
        for k in range(count):
            g=play(seed=args.seed+i*100000+k,white_policy=w,black_policy=b,depth=args.depth,limit=args.limit)
            co[g['outcome']]+=1;ls.append(g['plies']);cap+=g['captures'];passes+=g['passes']
        print(f'{w:>6} vs {b:<6}: {dict(co)}  mean plies={statistics.mean(ls):.1f} captures={cap} passes={passes}')
        report['matchups'][f'{w}_vs_{b}']={'games':count,'outcomes':dict(co),'mean_plies':statistics.mean(ls),'captures':cap,'passes':passes}
        overall.update(co);lengths.extend(ls)
    decisive=overall['white']+overall['black']
    report['overall']={'outcomes':dict(overall),'mean_plies':statistics.mean(lengths),'white_share_decisive':overall['white']/decisive if decisive else None}
    print('OVERALL',report['overall'])
    if args.output:
        with open(args.output,'w') as f:json.dump(report,f,indent=2)
    # Store deterministic complete sample for inspection.
    game=play(args.seed,white_policy='greedy',black_policy='greedy',limit=args.limit,record=True)
    if args.output:
        with open(args.output.replace('.json','_sample.json'),'w') as f:json.dump(game,f,indent=2)

if __name__=='__main__':main()

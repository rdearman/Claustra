from boxed_hexagram_solver import XY,TRACKS,HOME,SAFE,GOAL,ADJ,ID,NAMES
import json
from xml.sax.saxutils import escape
P='/mnt/data/boxed_hexagram/'
# Track lines for all 13 straight lines, circles at their intersections.
def xy(n):
    x,y=XY[n]
    return (85+(x+1)*92, 75+(6-y)*90)
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1050" height="790" viewBox="0 0 1050 790">',
'<rect width="1050" height="790" rx="20" fill="#f9f7f1"/>',
'<text x="40" y="39" font-family="sans-serif" font-size="23" font-weight="bold" fill="#222">BOXED HEXAGRAM · 24 vertices</text>',
'<text x="40" y="758" font-family="sans-serif" font-size="15" fill="#374151">White starts below · Black starts above · coloured outlines denote victory targets</text>']
for t in TRACKS:
    coords=' '.join(f'{xy(n)[0]:.1f},{xy(n)[1]:.1f}' for n in t)
    svg.append(f'<polyline points="{coords}" fill="none" stroke="#334155" stroke-width="3.8" stroke-linejoin="round"/>')
for n,(x,y) in XY.items():
    px,py=xy(n)
    if n in HOME[0]:fill,stroke='#fdfdfd','#294d85'
    elif n in HOME[1]:fill,stroke='#222831','#222831'
    else:fill,stroke='#f9f7f1','#526274'
    if n in GOAL[0]:stroke='#3b82f6'
    if n in GOAL[1]:stroke='#d97706'
    svg.append(f'<circle cx="{px}" cy="{py}" r="18" fill="{fill}" stroke="{stroke}" stroke-width="3.5"/>')
    labelcolor='#fff' if n in HOME[1] else '#111827'
    svg.append(f'<text x="{px}" y="{py+5}" fill="{labelcolor}" font-family="monospace" font-size="13" font-weight="bold" text-anchor="middle">{n}</text>')
svg.append('</svg>')
open(P+'boxed_hexagram_board.svg','w').write('\n'.join(svg))
dictout={'id':'BH24','name':'Boxed Hexagram','coordinates':{k:{'x':v[0],'y':v[1]} for k,v in XY.items()},'tracks':TRACKS,'start':{'white':HOME[0],'black':HOME[1]},'protected':{'white':sorted(SAFE[0]),'black':sorted(SAFE[1])},'victory':{'white':sorted(GOAL[0]),'black':sorted(GOAL[1])},'vertices':list(XY)}
open(P+'boxed_hexagram_graph.json','w').write(json.dumps(dictout,indent=2))
